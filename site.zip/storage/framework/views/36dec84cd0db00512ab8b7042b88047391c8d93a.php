

<?php $__env->startSection('content'); ?>
    <div class="create-post-window">
        <div class="create-post-panel">
            <?php echo Form::open(['action' => 'App\Http\Controllers\WorkController@store', 'method' => 'POST']); ?>

            <div class="form-group">
                <?php echo e(Form::label('user_id', 'Darbinieka vārds, uzvārds')); ?>

                <?php echo e(Form::select('user_id', $users, null, ['required', 'class' => 'form-control create-title'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('object_id', 'Objekts')); ?>

                <?php echo e(Form::text('object_id', '', ['required', 'class' => 'form-control create-title'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('date', 'Datums')); ?>

                <?php echo e(Form::date('date', null, ['required', 'class' => 'form-control create-title'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('hours', 'Stundas')); ?>

                <?php echo e(Form::textarea('hours', '', ['required', 'class' => 'form-control create-body', 'style' => 'resize: none'])); ?>

            </div>
            <?php echo e(Form::submit('Izveidot', ['class' => 'create-btn'])); ?>

            <?php echo Form::close(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\intecrole\resources\views/work/create.blade.php ENDPATH**/ ?>
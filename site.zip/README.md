# Kvalifikācijas darbs 2023-2024

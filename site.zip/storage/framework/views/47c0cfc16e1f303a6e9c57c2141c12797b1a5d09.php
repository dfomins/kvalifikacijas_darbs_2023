

<?php $__env->startSection('content'); ?>
    <div class="sidebar">
        <div class="sidebar-content panel-standart">
            <h3 class="name"><?php echo e(auth()->user()->fname); ?> <?php echo e(auth()->user()->lname); ?></h3>
            <img src="img/pfp.jpg" alt="Profila bilde" class="sidebar-pfp" />
            <div class="settings">
                <p>Mainīt profila bildi(-)</p>
                <div class="pfp">
                    <p><?php echo e(Form::file('cover_image')); ?></p>
                </div>
                <a href="#">
                    <p></p>
                </a>
                <a href="/register">
                    <p>Izveidot jaunu lietotāju</p>
                </a>
            </div>
        </div>
    </div>
    <div class="centerbar">
        <div class="centerbar-panel">
            <div class="upper upper-day" id="upperDay">
                <ul>
                    <li class="day"></li>
                    <li class="date"></li>
                </ul>
            </div>
            <div class="centerbar-content panel-standart">
                <p>Statuss:</p>
                <p>Nostrādātas stundas:</p>
            </div>
        </div>
        <div class="centerbar-panel">
            <div class="upper upper-month" id="upperMonth">
                <ul>
                    <li class="previous">&#10094;</li>
                    <li class="next">&#10095;</li>
                    <li class="month"></li>
                    <li class="year"></li>
                </ul>
            </div>
            <div class="centerbar-content panel-standart calendar">
                <div class="weekdays">
                    <div>P</div>
                    <div>O</div>
                    <div>T</div>
                    <div>C</div>
                    <div>P</div>
                    <div><strong>S</strong></div>
                    <div><strong>Sv</strong></div>
                </div>
                <div class="grid-calendar days"></div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\intecrole2\resources\views/pages/profile.blade.php ENDPATH**/ ?>
@extends('layouts.app')

@section('content')
    <div class="note-window">
        <div class="note-panel panel-standart">
            <div class="title">
                <h2>Paziņojumi</h2>
            </div>
            <div class="threads">
                <ol>
                    @if (count($notifs) > 0)
                        @foreach ($notifs as $notif)
                            <li class="row">
                                <div class="title-text-post">
                                    <h3><a href="/notifications/{{ $notif->id }}">{{ $notif->title }}</a></h3>
                                    <p class="timestamp">Izveidots: {{ $notif->created_at->format('d-m-Y') }}</p>
                                </div>
                        @endforeach
                    @else
                        <p style="text-align: center">Paziņojumu nav</p>
                        </li>
                    @endif
                </ol>
            </div>
            @if (Auth::user()->role == 1)
                {
                <a href="notifications/create" id="btn"><input type="button" name="button" value="Izveidot jaunu"
                        id="btn" /></a>
                }
            @endif
        </div>
    </div>
@endsection

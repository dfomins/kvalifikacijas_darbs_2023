
<?php $__env->startSection('content'); ?>
    <div class="post-show-window">
        <div class="post-show-panel panel-standart">
            <div class="title-post-show">
                <a href="/notifications">
                    <div class="title-text-post-show-back-icon">
                        <i class="fa-sharp fa-solid fa-arrow-left"></i>
                    </div>
                </a>
                <div class="title-text-post-show">
                    <div class="title-text-post-show-content">
                        <h1><?php echo e($notif->title); ?></h1>
                        <p><?php echo e($notif->created_at->format('d-m-Y | H:i')); ?> || <?php echo e($notif->user->fname); ?>

                            <?php echo e($notif->user->lname); ?></p>
                    </div>
                    <?php if(Auth::user()->role == 1): ?>
                        <div class="title-icon-post">
                            <a href="/notifications/<?php echo e($notif->id); ?>/edit"><i
                                    class="fa-solid fa-pen-to-square fa-lg"></i></a>
                            <?php echo Form::open([
                                'action' => ['App\Http\Controllers\NotifsController@destroy', $notif->id],
                                'method' => 'DELETE',
                                'class' => 'btn',
                            ]); ?>

                            <?php echo e(Form::button('<i class="fa-solid fa-trash fa-xl"></i>', ['type' => 'submit', 'class' => 'delete-btn'])); ?>

                            <?php echo Form::close(); ?>

                        </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="body-content-post-show">
                <p><?php echo e($notif->body); ?></p>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\intecrole\resources\views/notifs/show.blade.php ENDPATH**/ ?>
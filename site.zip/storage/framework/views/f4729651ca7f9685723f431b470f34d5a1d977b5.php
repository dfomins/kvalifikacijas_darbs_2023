

<?php $__env->startSection('content'); ?>
    <div class="work-window">
        <div class="work-panel panel-standart">
            <div>
                <p>Šeit būs filtrs</p>
            </div>
            <table>
                <tr>
                    <th>Vārds, uzvārds</th>
                    <th>Objekts</th>
                    <th>Datums</th>
                    <th>Stundu skaits</th>
                </tr>
                <tr>
                    <td>Ivans Duļins</td>
                    <td>4</td>
                    <td>28.02.12.</td>
                    <td>8</td>
                </tr>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\intecrole\resources\views/pages/work.blade.php ENDPATH**/ ?>
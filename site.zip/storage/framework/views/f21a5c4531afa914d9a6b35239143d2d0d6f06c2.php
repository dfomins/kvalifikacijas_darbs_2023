

<?php $__env->startSection('content'); ?>
    <div class="create-post-window">
        <div class="create-post-panel">
            <?php echo Form::open(['action' => 'App\Http\Controllers\NotifsController@store', 'method' => 'POST']); ?>

            <div class="form-group">
                <?php echo e(Form::label('title', 'Nosaukums')); ?>

                <?php echo e(Form::text('title', '', ['required', 'class' => 'form-control create-title'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('body', 'Saturs')); ?>

                <?php echo e(Form::textarea('body', '', ['required', 'class' => 'form-control create-body', 'style' => 'resize: none'])); ?>

            </div>
            <?php echo e(Form::submit('Izveidot', ['class' => 'create-btn'])); ?>

            <?php echo Form::close(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\intecrole\resources\views/notifs/create.blade.php ENDPATH**/ ?>
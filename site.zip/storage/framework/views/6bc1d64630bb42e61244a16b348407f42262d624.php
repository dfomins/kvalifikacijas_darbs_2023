

<?php $__env->startSection('content'); ?>
    <div class="note-window">
        <div class="note-panel panel-standart">
            <div class="title">
                <h2>Informācija par objektiem</h2>
            </div>
            <div class="threads">
                <ol>
                    <?php if(count($objects) > 0): ?>
                        <?php $__currentLoopData = $objects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $object): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="row">
                                <div class="title-text-post">
                                    <h3><a href="/objects/<?php echo e($object->id); ?>"><?php echo e($object->id); ?> | <?php echo e($object->title); ?></a>
                                    </h3>
                                </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <p style="text-align: center">Informācijas par objektiem nav</p>
                        </li>
                    <?php endif; ?>
                </ol>
            </div>
            <?php if(Auth::user()->role == 1): ?>
                {
                <a href="/objects/create" id="btn"><input type="button" name="button" value="Izveidot jaunu"
                        id="btn" /></a>
                }
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\intecrole\resources\views/objects/index.blade.php ENDPATH**/ ?>
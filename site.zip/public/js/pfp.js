document.querySelector(".change-pfp-button").addEventListener("click", () => {
    document.querySelector(".pfp input").style.display = "flex";
    console.log("block");
})
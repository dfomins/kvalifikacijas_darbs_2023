

<?php $__env->startSection('content'); ?>
    <div class="work-window">
        <div class="work-panel panel-standart">
            
            <form action="">
                <input type="search" name="search" id="" placeholder="Meklēšana pēc vārda"
                    value="<?php echo e($search); ?>">
                <input type="submit" id="btn" value="Meklēt">
            </form>
            <table>
                <?php if(count($works) > 0): ?>
                    <tr>
                        <th>Vārds, uzvārds</th>
                        <th>Objekts</th>
                        <th>Datums</th>
                        <th>Stundu skaits</th>
                    </tr>
                    <?php $__currentLoopData = $works; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $work): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($work->user->fname); ?> <?php echo e($work->user->lname); ?> (ID: <?php echo e($work->user->id); ?>)</td>
                            <td><?php echo e($work->object_id); ?></td>
                            <td><?php echo e(date('d/m/Y', strtotime($work->date))); ?></td>
                            <td><?php echo e($work->hours); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <p style="text-align: center">Informācijas par objektiem nav</p>
                    </li>
                <?php endif; ?>
            </table>
            <?php if(Auth::user()->role == 1): ?>
                <a href="/work/create" id="btn"><input type="button" name="button" value="Izveidot jaunu"
                        id="btn" /></a>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\intecrole\resources\views/workrecords/index.blade.php ENDPATH**/ ?>
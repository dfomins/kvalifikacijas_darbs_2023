// SIDEBAR

    document.querySelector(".closeMenu").addEventListener("click", () => {
        navLinks.style.right = "-200px";
    })

    document.querySelector(".openMenu").addEventListener("click", () => {
        navLinks.style.right = "0px";
    })
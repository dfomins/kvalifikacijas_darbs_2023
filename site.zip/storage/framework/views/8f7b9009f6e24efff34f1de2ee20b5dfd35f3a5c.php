<?php $__env->startSection('content'); ?>
    <div class="login-panel">
        <div class="login-panel">
            <img src="../images/logo.png" alt="" />
            <h1>Pieslēgšanās lapa</h1>
            <form method="POST" action="<?php echo e(route('login')); ?>">
                <?php echo csrf_field(); ?>

                <input type="text" name="email" placeholder="E-pasts" value="<?php echo e(old('email')); ?>" />
                <span style="color: red">
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <?php echo e($message); ?>

                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </span>

                <input type="password" name="password" placeholder="Parole" />
                <span style="color: red">
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <?php echo e($message); ?>

                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </span>

                <button type="submit" name="button" id="btn">Pieslēgties</button>

                <?php if(Route::has('password.request')): ?>
                    <p><a href="<?php echo e(route('password.request')); ?>">Aizmirsāt paroli?</a></p>
                <?php endif; ?>
            </form>
        </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\intecrole\resources\views/auth/login.blade.php ENDPATH**/ ?>
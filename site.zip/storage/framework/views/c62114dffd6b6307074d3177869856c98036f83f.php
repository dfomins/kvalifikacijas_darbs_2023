
<?php $__env->startSection('content'); ?>
    <div class="post-show-window">
        <div class="post-show-panel panel-standart">
            <div class="title-post-show">
                <a href="/objects">
                    <div class="title-text-post-show-back-icon">
                        <i class="fa-sharp fa-solid fa-arrow-left"></i>
                    </div>
                </a>
                <div class="title-text-post-show">
                    <div class="title-text-post-show-content">
                        <h1><?php echo e($object->id); ?> | <?php echo e($object->title); ?></h1>
                    </div>
                    <div class="title-icon-post">
                        <a href="/objects/<?php echo e($object->id); ?>/edit"><i class="fa-solid fa-pen-to-square fa-lg"></i></a>
                        <?php echo Form::open([
                            'action' => ['App\Http\Controllers\ObjectsController@destroy', $object->id],
                            'method' => 'DELETE',
                            'class' => 'btn',
                        ]); ?>

                        <?php echo e(Form::button('<i class="fa-solid fa-trash fa-xl"></i>', ['type' => 'submit', 'class' => 'delete-btn'])); ?>

                        <?php echo Form::close(); ?>

                    </div>
                </div>
            </div>
            <div class="body-content-post-show">
                <p><?php echo e($object->body); ?></p>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\intecrole\resources\views/objects/show.blade.php ENDPATH**/ ?>
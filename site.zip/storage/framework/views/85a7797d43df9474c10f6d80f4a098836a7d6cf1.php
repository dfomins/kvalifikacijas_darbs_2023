

<?php $__env->startSection('content'); ?>
    <div class="note-window">
        <div class="note-panel panel-standart">
            <div class="title">
                <h2>Paziņojumi</h2>
            </div>
            <div class="threads">
                <ol>
                    <?php if(count($notifs) > 0): ?>
                        <?php $__currentLoopData = $notifs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notif): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="row">
                                <div class="title-text-post">
                                    <h3><a href="/notifications/<?php echo e($notif->id); ?>"><?php echo e($notif->title); ?></a></h3>
                                    <p class="timestamp">Izveidots: <?php echo e($notif->created_at->format('d-m-Y')); ?></p>
                                </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <p style="text-align: center">Paziņojumu nav</p>
                        </li>
                    <?php endif; ?>
                </ol>
            </div>
            <?php if(Auth::user()->role == 1): ?>
                {
                <a href="notifications/create" id="btn"><input type="button" name="button" value="Izveidot jaunu"
                        id="btn" /></a>
                }
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\intecrole\resources\views/notifs/index.blade.php ENDPATH**/ ?>